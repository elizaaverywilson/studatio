"""
iCalEvents search all events occurring in a given time frame in an iCal file.
"""

__all__ = ['icaldownload', 'icalparser', 'icalevents']
